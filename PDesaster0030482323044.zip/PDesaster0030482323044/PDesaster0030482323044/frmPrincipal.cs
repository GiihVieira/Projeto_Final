﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace PDesaster0030482323044
{
    public partial class frmPrincipal : Form
    {

        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection conexao = dbConnection.GetConnection();
                conexao.Open();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Erro de banco de dados =/" + ex.Message);
            }
            catch (Exception ex) 
            {
                MessageBox.Show("Outros Erros =/" + ex.Message);
            }
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void cadastroTiposDeEventosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmTipo>().Count() > 0)
            {
                Application.OpenForms["frmTipo"].BringToFront();
            }
            else
            {
                frmTipo objfrmTipo = new frmTipo();
                objfrmTipo.MdiParent = this;
                objfrmTipo.WindowState = FormWindowState.Maximized;
                objfrmTipo.Show();
            }
        }

        private void cadastroCidadesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmCidade>().Count() > 0)
            {
                Application.OpenForms["frmCidades"].BringToFront();
            }
            else
            {
                frmCidade objfrmCidade = new frmCidade();
                objfrmCidade.MdiParent = this;
                objfrmCidade.WindowState = FormWindowState.Maximized;
                objfrmCidade.Show();
            }
        }

        private void cadastroEventosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmEvento>().Count() > 0)
            {
                Application.OpenForms["frmEvento"].BringToFront();
            }
            else
            {
                frmEvento objfrmEvento = new frmEvento();
                objfrmEvento.MdiParent = this;
                objfrmEvento.WindowState = FormWindowState.Maximized;
                objfrmEvento.Show();
            }
        }

        private void sobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmSobre>().Count() > 0)
            {
                Application.OpenForms["frmSobre"].BringToFront();
            }
            else
            {
                frmSobre objfrmSobre = new frmSobre();
                objfrmSobre.MdiParent = this;
                objfrmSobre.WindowState = FormWindowState.Maximized;
                objfrmSobre.Show();
            }
        }
    }
}
