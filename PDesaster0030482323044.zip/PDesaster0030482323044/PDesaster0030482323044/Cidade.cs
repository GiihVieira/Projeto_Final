﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace PDesaster0030482323044
{
    internal class Cidade
    {
        public int IdCidade { get; set; }
        public string Nome { get; set; }
        public string UF { get; set; }
        public int Populacao { get; set; }

        public DataTable Listar()
        {
            SqlDataAdapter daCidade;
            DataTable dtCidade = new DataTable();
            string query = "SELECT * FROM Cidade ORDER BY Nome";

            try
            {
                using (SqlConnection conexao = dbConnection.GetConnection())
                {
                    daCidade = new SqlDataAdapter(query, conexao);
                    conexao.Open();
                    daCidade.Fill(dtCidade);
                    daCidade.FillSchema(dtCidade, SchemaType.Source);
                }
            }
            catch (Exception)
            {
                throw;
            }
            return dtCidade;
        }

        public int Incluir()
        {
            int retorno = 0;
            string query = "INSERT INTO Cidade VALUES (@NOME, @UF, @POPULACAO)";

            try
            {
                using (SqlConnection conexao = dbConnection.GetConnection())
                {
                    SqlCommand mycommand = new SqlCommand(query, conexao);

                    mycommand.Parameters.Add(new SqlParameter("@NOME", SqlDbType.VarChar));
                    mycommand.Parameters.Add(new SqlParameter("@UF", SqlDbType.Char));
                    mycommand.Parameters.Add(new SqlParameter("@POPULACAO", SqlDbType.Int));

                    mycommand.Parameters["@NOME"].Value = Nome;
                    mycommand.Parameters["@UF"].Value = UF;
                    mycommand.Parameters["@POPULACAO"].Value = Populacao;

                    conexao.Open();
                    retorno = mycommand.ExecuteNonQuery();
                }
            }
            catch (Exception)
            {
                throw;
            }
            return retorno;
        }

        public int Alterar()
        {
            int retorno = 0;
            string query = "UPDATE Cidade SET Nome=@Nome, UF=@UF, Populacao=@Populacao WHERE IdCidade=@IdCidade";

            try
            {
                using (SqlConnection conexao = dbConnection.GetConnection())
                {
                    SqlCommand mycommand = new SqlCommand(query, conexao);

                    mycommand.Parameters.Add(new SqlParameter("@IdCidade", SqlDbType.Int));
                    mycommand.Parameters.Add(new SqlParameter("@Nome", SqlDbType.VarChar));
                    mycommand.Parameters.Add(new SqlParameter("@UF", SqlDbType.Char));
                    mycommand.Parameters.Add(new SqlParameter("@Populacao", SqlDbType.Int));

                    mycommand.Parameters["@IdCidade"].Value = IdCidade;
                    mycommand.Parameters["@Nome"].Value = Nome;
                    mycommand.Parameters["@UF"].Value = UF;
                    mycommand.Parameters["@Populacao"].Value = Populacao;

                    conexao.Open();
                    retorno = mycommand.ExecuteNonQuery();
                }
            }
            catch (Exception)
            {
                throw;
            }
            return retorno;
        }

        public int Excluir()
        {
            int nReg = 0;
            string query = "DELETE FROM Cidade WHERE IdCidade=@IdCidade";

            try
            {
                using (SqlConnection conexao = dbConnection.GetConnection())
                {
                    SqlCommand mycommand = new SqlCommand(query, conexao);

                    mycommand.Parameters.Add(new SqlParameter("@IdCidade", SqlDbType.Int));
                    mycommand.Parameters["@IdCidade"].Value = IdCidade;

                    conexao.Open();
                    nReg = mycommand.ExecuteNonQuery();
                }
            }
            catch (Exception)
            {
                throw;
            }
            return nReg;
        }
    }
}
