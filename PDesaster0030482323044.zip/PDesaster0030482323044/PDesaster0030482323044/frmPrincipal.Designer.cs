﻿namespace PDesaster0030482323044
{
    partial class frmPrincipal
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.mnuPrincipal = new System.Windows.Forms.MenuStrip();
            this.outroCadastrosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cadastroCidadesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cadastroTiposDeEventosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cadastroEventosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sobreToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sairToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuPrincipal.SuspendLayout();
            this.SuspendLayout();
            // 
            // mnuPrincipal
            // 
            this.mnuPrincipal.Font = new System.Drawing.Font("Segoe UI Semibold", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mnuPrincipal.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.mnuPrincipal.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.outroCadastrosToolStripMenuItem,
            this.cadastroEventosToolStripMenuItem,
            this.sobreToolStripMenuItem,
            this.sairToolStripMenuItem});
            this.mnuPrincipal.Location = new System.Drawing.Point(0, 0);
            this.mnuPrincipal.Name = "mnuPrincipal";
            this.mnuPrincipal.Size = new System.Drawing.Size(1451, 33);
            this.mnuPrincipal.TabIndex = 0;
            this.mnuPrincipal.Text = "menuStrip1";
            // 
            // outroCadastrosToolStripMenuItem
            // 
            this.outroCadastrosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cadastroCidadesToolStripMenuItem,
            this.cadastroTiposDeEventosToolStripMenuItem});
            this.outroCadastrosToolStripMenuItem.Name = "outroCadastrosToolStripMenuItem";
            this.outroCadastrosToolStripMenuItem.Size = new System.Drawing.Size(162, 29);
            this.outroCadastrosToolStripMenuItem.Text = "Outro Cadastros";
            // 
            // cadastroCidadesToolStripMenuItem
            // 
            this.cadastroCidadesToolStripMenuItem.Name = "cadastroCidadesToolStripMenuItem";
            this.cadastroCidadesToolStripMenuItem.Size = new System.Drawing.Size(317, 30);
            this.cadastroCidadesToolStripMenuItem.Text = "Cadastro Cidades";
            this.cadastroCidadesToolStripMenuItem.Click += new System.EventHandler(this.cadastroCidadesToolStripMenuItem_Click);
            // 
            // cadastroTiposDeEventosToolStripMenuItem
            // 
            this.cadastroTiposDeEventosToolStripMenuItem.Name = "cadastroTiposDeEventosToolStripMenuItem";
            this.cadastroTiposDeEventosToolStripMenuItem.Size = new System.Drawing.Size(317, 30);
            this.cadastroTiposDeEventosToolStripMenuItem.Text = "Cadastro Tipos de Eventos";
            this.cadastroTiposDeEventosToolStripMenuItem.Click += new System.EventHandler(this.cadastroTiposDeEventosToolStripMenuItem_Click);
            // 
            // cadastroEventosToolStripMenuItem
            // 
            this.cadastroEventosToolStripMenuItem.Name = "cadastroEventosToolStripMenuItem";
            this.cadastroEventosToolStripMenuItem.Size = new System.Drawing.Size(169, 29);
            this.cadastroEventosToolStripMenuItem.Text = "Cadastro Eventos";
            this.cadastroEventosToolStripMenuItem.Click += new System.EventHandler(this.cadastroEventosToolStripMenuItem_Click);
            // 
            // sobreToolStripMenuItem
            // 
            this.sobreToolStripMenuItem.Name = "sobreToolStripMenuItem";
            this.sobreToolStripMenuItem.Size = new System.Drawing.Size(75, 29);
            this.sobreToolStripMenuItem.Text = "Sobre";
            this.sobreToolStripMenuItem.Click += new System.EventHandler(this.sobreToolStripMenuItem_Click);
            // 
            // sairToolStripMenuItem
            // 
            this.sairToolStripMenuItem.Name = "sairToolStripMenuItem";
            this.sairToolStripMenuItem.Size = new System.Drawing.Size(57, 29);
            this.sairToolStripMenuItem.Text = "Sair";
            this.sairToolStripMenuItem.Click += new System.EventHandler(this.sairToolStripMenuItem_Click);
            // 
            // frmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1451, 573);
            this.Controls.Add(this.mnuPrincipal);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.mnuPrincipal;
            this.Name = "frmPrincipal";
            this.Text = "CADASTRO DE DESASTRE NATURAIS";
            this.mnuPrincipal.ResumeLayout(false);
            this.mnuPrincipal.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mnuPrincipal;
        private System.Windows.Forms.ToolStripMenuItem outroCadastrosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cadastroCidadesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cadastroTiposDeEventosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cadastroEventosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sobreToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sairToolStripMenuItem;
    }
}

