﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace PDesaster0030482323044
{
    internal class Tipo
    {

        public int IdTipo { get; set; }
        public string Descricao { get; set; }

        public DataTable Listar()
        {
            DataTable dtTipo = new DataTable();
            string query = "SELECT * FROM Tipo ORDER BY DESCRICAO";

            try
            {
                using (SqlConnection conexao = dbConnection.GetConnection())
                {
                    SqlDataAdapter daTipo = new SqlDataAdapter(query, conexao);
                    conexao.Open();
                    daTipo.Fill(dtTipo);
                    daTipo.FillSchema(dtTipo, SchemaType.Source);
                }
            }
            catch (Exception ex)
            {
                // Adiciona detalhes da exceção à mensagem de erro
                throw new Exception("Erro ao listar os tipos: " + ex.Message);
            }

            return dtTipo;
        }

        public int Incluir()
        {
            int retorno = 0;
            string query = "INSERT INTO Tipo (DESCRICAO) VALUES (@DESCRICAO)";

            try
            {
                using (SqlConnection conexao = dbConnection.GetConnection())
                {
                    SqlCommand mycommand = new SqlCommand(query, conexao);
                    mycommand.Parameters.Add(new SqlParameter("@DESCRICAO", SqlDbType.VarChar)).Value = Descricao;
                    conexao.Open();
                    retorno = mycommand.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                // Adiciona detalhes da exceção à mensagem de erro
                throw new Exception("Erro ao incluir o tipo: " + ex.Message);
            }

            return retorno;
        }

        public int Alterar()
        {
            int retorno = 0;
            string query = "UPDATE Tipo SET DESCRICAO=@DESCRICAO WHERE IDTipo=@IDTipo";

            try
            {
                using (SqlConnection conexao = dbConnection.GetConnection())
                {
                    SqlCommand mycommand = new SqlCommand(query, conexao);
                    mycommand.Parameters.Add(new SqlParameter("@IDTipo", SqlDbType.Int)).Value = IdTipo;
                    mycommand.Parameters.Add(new SqlParameter("@DESCRICAO", SqlDbType.VarChar)).Value = Descricao;
                    conexao.Open();
                    retorno = mycommand.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                // Adiciona detalhes da exceção à mensagem de erro
                throw new Exception("Erro ao alterar o tipo: " + ex.Message);
            }

            return retorno;
        }

        public int Excluir()
        {
            int nReg = 0;
            string query = "DELETE FROM Tipo WHERE IDTipo=@IDTipo";

            try
            {
                using (SqlConnection conexao = dbConnection.GetConnection()){
                    SqlCommand mycommand = new SqlCommand(query, conexao);
                    mycommand.Parameters.Add(new SqlParameter("@IDTipo", SqlDbType.Int)).Value = IdTipo;
                    conexao.Open();
                    nReg = mycommand.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                // Adiciona detalhes da exceção à mensagem de erro
                throw new Exception("Erro ao excluir o tipo: " + ex.Message);
            }

            return nReg;
        }
    }
}
