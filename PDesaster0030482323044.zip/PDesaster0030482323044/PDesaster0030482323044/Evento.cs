﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace PDesaster0030482323044
{
    internal class Evento
    {
        public int IdEvento { get; set; }
        public int Tipo_IdTipo { get; set; }
        public int Cidade_IdCidade { get; set; }
        public char NivelSeveridade { get; set; }
        public int AreaAfetada { get; set; }
        public int PessoasAfetadas { get; set; }
        public string Observacao { get; set; }
        public DateTime DataOcorrencia { get; set; }

        public DataTable Listar()
        {
            SqlDataAdapter daEvento;
            DataTable dtEvento = new DataTable();
            string query = "SELECT * FROM Evento ORDER BY IDEVENTO";

            try
            {
                using (SqlConnection conexao = dbConnection.GetConnection())
                {
                    daEvento = new SqlDataAdapter(query, conexao);
                    conexao.Open();
                    daEvento.Fill(dtEvento);
                    daEvento.FillSchema(dtEvento, SchemaType.Source);
                }
            }
            catch (Exception)
            {
                throw;
            }
            return dtEvento;
        }

        public int Incluir()
        {
            int retorno = 0;
            string query = "INSERT INTO Evento (TIPO_IDTIPO, CIDADE_IDCIDADE, NIVELSEVERIDADE, AREAAFETADA, PESSOASAFETADAS, OBSERVACAO, DATAOCORRENCIA) " +
                           "VALUES (@IDTIPO, @IDCIDADE, @NIVELSEVERIDADE, @AREAAFETADA, @PESSOASAFETADAS, @OBSERVACAO, @DATAOCORRENCIA)";

            try
            {
                using (SqlConnection conexao = dbConnection.GetConnection())
                {
                    using (SqlCommand mycommand = new SqlCommand(query, conexao))
                    {
                        mycommand.Parameters.Add(new SqlParameter("@IDTIPO", SqlDbType.Int)).Value = Tipo_IdTipo;
                        mycommand.Parameters.Add(new SqlParameter("@IDCIDADE", SqlDbType.Int)).Value = Cidade_IdCidade;
                        mycommand.Parameters.Add(new SqlParameter("@NIVELSEVERIDADE", SqlDbType.Char)).Value = NivelSeveridade;
                        mycommand.Parameters.Add(new SqlParameter("@AREAAFETADA", SqlDbType.Int)).Value = AreaAfetada;
                        mycommand.Parameters.Add(new SqlParameter("@PESSOASAFETADAS", SqlDbType.Int)).Value = PessoasAfetadas;
                        mycommand.Parameters.Add(new SqlParameter("@OBSERVACAO", SqlDbType.VarChar)).Value = Observacao;
                        mycommand.Parameters.Add(new SqlParameter("@DATAOCORRENCIA", SqlDbType.DateTime)).Value = DataOcorrencia;

                        conexao.Open();
                        retorno = mycommand.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
            return retorno;
        }

        public int Alterar()
        {
            int retorno = 0;
            string query = "UPDATE Evento SET TIPO_IDTIPO=@IDTIPO, CIDADE_IDCIDADE=@IDCIDADE, NIVELSEVERIDADE=@NIVELSEVERIDADE, AREAAFETADA=@AREAAFETADA, " +
                           "PESSOASAFETADAS=@PESSOASAFETADAS, OBSERVACAO=@OBSERVACAO, DATAOCORRENCIA=@DATAOCORRENCIA WHERE IDEVENTO=@IDEVENTO";

            try
            {
                using (SqlConnection conexao = dbConnection.GetConnection())
                {
                    using (SqlCommand mycommand = new SqlCommand(query, conexao))
                    {
                        mycommand.Parameters.Add(new SqlParameter("@IDEVENTO", SqlDbType.Int)).Value = IdEvento;
                        mycommand.Parameters.Add(new SqlParameter("@IDTIPO", SqlDbType.Int)).Value = Tipo_IdTipo;
                        mycommand.Parameters.Add(new SqlParameter("@IDCIDADE", SqlDbType.Int)).Value = Cidade_IdCidade;
                        mycommand.Parameters.Add(new SqlParameter("@NIVELSEVERIDADE", SqlDbType.Char)).Value = NivelSeveridade;
                        mycommand.Parameters.Add(new SqlParameter("@AREAAFETADA", SqlDbType.Int)).Value = AreaAfetada;
                        mycommand.Parameters.Add(new SqlParameter("@PESSOASAFETADAS", SqlDbType.Int)).Value = PessoasAfetadas;
                        mycommand.Parameters.Add(new SqlParameter("@OBSERVACAO", SqlDbType.VarChar)).Value = Observacao;
                        mycommand.Parameters.Add(new SqlParameter("@DATAOCORRENCIA", SqlDbType.DateTime)).Value = DataOcorrencia;

                        conexao.Open();
                        retorno = mycommand.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
            return retorno;
        }

        public int Excluir()
        {
            int nReg = 0;
            string query = "DELETE FROM Evento WHERE IDEvento=@IDEvento";

            try
            {
                using (SqlConnection conexao = dbConnection.GetConnection())
                {
                    using (SqlCommand mycommand = new SqlCommand(query, conexao))
                    {
                        mycommand.Parameters.Add(new SqlParameter("@IDEvento", SqlDbType.Int)).Value = IdEvento;
                        conexao.Open();
                        nReg = mycommand.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
            return nReg;
        }
    }
}
