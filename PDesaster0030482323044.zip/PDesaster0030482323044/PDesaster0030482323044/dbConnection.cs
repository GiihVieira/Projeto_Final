﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace PDesaster0030482323044
{
    internal static class dbConnection
    {
        private static readonly string connectionString = "Data Source=Giovane;Initial Catalog=LP2;Integrated Security=True;Encrypt=False";

        public static SqlConnection GetConnection()
        {
            return new SqlConnection(connectionString);
        }
    }
}
